export type SupportedLanguage = "pt-BR" | "it-IT" | "en-US"
export type GutoAvatarEmotion = "default" | "alert" | "critical" | "reward"

export type EvolutionStage = "baby" | "teen" | "adult" | "elite"

export interface GutoHistoryItem {
  role: "user" | "model"
  parts: { text: string }[]
}

export interface SendGutoMessageRequest {
  profile: { 
    name: string
    evolution?: EvolutionStage
  }
  input: string
  language: SupportedLanguage
  history: GutoHistoryItem[]
}

export interface SendGutoMessageResponse {
  fala?: string
  acao?: "none" | "updateWorkout" | "lock" | "evolve"
  newEvolution?: EvolutionStage
  avatarEmotion?: GutoAvatarEmotion
}
