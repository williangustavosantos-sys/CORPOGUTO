# Task Progress - Limpar warnings de lint e fazer push

- [x] Diagnosticar todos os warnings (31 warnings, 0 erros)
- [ ] Corrigir tab-acesso.tsx - remover `teams` não usado
- [ ] Corrigir tab-resumo.tsx - remover `user` não usado
- [ ] Corrigir use-coach-data.ts - adicionar `filters` nas deps
- [ ] Corrigir use-student-detail.ts - remover `_exerciseCatalog`
- [ ] Corrigir cockpit-context.tsx - remover argumento `_exerciseCatalog`
- [ ] Corrigir coach/page.tsx - adicionar `copy` nas deps + remover `student`
- [ ] Corrigir guto-app.tsx - 11 warnings (imports não usados, hooks deps, etc)
- [ ] Corrigir chat-tab.tsx - adicionar deps + remover `latestGuto`
- [ ] Corrigir diet-tab.tsx - adicionar `todayCoachDiet` nas deps
- [ ] Corrigir mission-tab.tsx - remover props não usadas
- [ ] Corrigir path-tab.tsx - remover `avatarEmotion` + trocar `<img>` por `<Image>`
- [ ] Corrigir lib/api/guto.ts - remover `_arenaGroupId` params
- [ ] Rodar lint para verificar se zerou warnings
- [ ] Rodar build para verificar se continua passando
- [ ] Git add, commit e push para GitHub
